package avaliacao.f1;

public class Pilot extends Person {

    private int victory;

    public Pilot(String name, int age, String nationality, int victory){
        super(name, age, nationality);
        this.victory=victory;
    }

    public int getVictory() { return victory; }

    public void setVictory(int victory) { this.victory = victory; }
}
