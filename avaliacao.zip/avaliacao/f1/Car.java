package avaliacao.f1;

public class Car {

    private int number;
    private int position;
    private Team team;
    private Pilot pilot;
    private Engineer engineer;

    public Car(){

    }

    public Car(int number, int position, Team team, Pilot pilot, Engineer engineer){
        this.number=number;
        this.position=position;
        this.team=team;
        this.pilot=pilot;
        this.engineer=engineer;
    }

    public int getNumber(){
        return number;
    }

    public int getPosition(){
        return position;
    }

    public Team getTeam(){
        return team;
    }

    public Pilot getPilot(){
        return pilot;
    }

    public Engineer getEngineer() { return engineer; }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void setPilot(Pilot pilot) {
        this.pilot = pilot;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}
