package avaliacao.f1;

import java.util.ArrayList;

public class Team {

    private String name;
    private int foundationYear;
    private ArrayList<Sponsors> sponsors;

    public Team(String name, int foundationYear, ArrayList<Sponsors> sponsors){
        this.name=name;
        this.foundationYear=foundationYear;
        this.sponsors=sponsors;
    }

    public String getName() {
        return name;
    }

    public int getFoundationYear() {
        return foundationYear;
    }

    public ArrayList<Sponsors> getSponsors() {
        return sponsors;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setFoundationYear(int foundationYear) {
        this.foundationYear = foundationYear;
    }

    public void setSponsors(ArrayList<Sponsors> sponsors) {
        this.sponsors = sponsors;
    }
}
