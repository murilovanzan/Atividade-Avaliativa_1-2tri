package avaliacao.f1;

public class Sponsors {

    private String name;
    private double adValue;

    public Sponsors(String name, double adValue){
        this.name=name;
        this.adValue=adValue;
    }

    public String getName() {
        return name;
    }

    public double getAdValue() {
        return adValue;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAdValue(double adValue) {
        this.adValue = adValue;
    }
}

