package avaliacao.f1;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Sponsors marlboro = new Sponsors("Marlboro",250000.00);
        Sponsors monster = new Sponsors("Monster",350000.00);
        var ferrariSponsors = new ArrayList<Sponsors>();
        ferrariSponsors.add(marlboro);
        ferrariSponsors.add(monster);
        Team ferrari = new Team("Ferrari",2000, ferrariSponsors);

        Pilot hamilton = new Pilot("Lewis Hamilton",31,"British",100);
        Pilot leclerc = new Pilot("Charles Leclerc",28,"Monegasque",50);
        var carloSantiPilots = new ArrayList<Pilot>();
        carloSantiPilots.add(hamilton);
        carloSantiPilots.add(leclerc);
        Engineer carloSanti = new Engineer("Carlo Santi", 52, "Italian", carloSantiPilots);
        Car carro1 = new Car(10,1,ferrari,hamilton,carloSanti);

        //Atribuição do carro que será mostrado
        Car F1 = carro1;
        System.out.println("Carro X:");

        //Print número do carro
        System.out.println("\tNúmero: " + F1.getNumber());

        //Print da posição do carro
        System.out.println("\tPosição: " + F1.getPosition());

        //Prints da equipe e seus atributos
        System.out.println("\tEquipe:\n\t\tNome: " + F1.getTeam().getName() + "\n\t\tAno de fundação: " + F1.getTeam().getFoundationYear());
        System.out.print("\t\tPatrocinadores:");
        for (Sponsors patrocinador : F1.getTeam().getSponsors()){
            System.out.print("\n\t\t\t" + patrocinador.getName() + "\n\t\t\t\tValor de patrocínio: " + patrocinador.getAdValue());
        }

        //Print do engenheiro e seus atributos
        System.out.println("\n\tEngenheiro:\n\t\tNome: " + F1.getEngineer().getName() + "\n\t\tIdade: " + F1.getEngineer().getAge() + "\n\t\tNacionalidade: " + F1.getEngineer().getNationality() + "\n\t\tPilotos:");
        for (Pilot piloto : F1.getEngineer().getPilotsOfTeam()){
            System.out.println("\t\t\t" + piloto.getName());
        }

        //Print do piloto e seus atributos
        System.out.println("\tPiloto:\n\t\tNome: " + F1.getPilot().getName() + "\n\t\tIdade: " + F1.getPilot().getAge() + "\n\t\tNacionalidade: " + F1.getPilot().getNationality() + "\n\t\tNúmero de vitórias: " + F1.getPilot().getVictory());

    }
}
