package avaliacao.f1;

public class Person {
    protected String name;
    protected int age;
    protected String nationality;

    public Person(String name, int age, String nationality){
        this.name=name;
        this.age=age;
        this.nationality=nationality;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getNationality() {
        return nationality;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }
}
