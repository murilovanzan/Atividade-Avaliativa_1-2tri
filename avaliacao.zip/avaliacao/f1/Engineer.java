package avaliacao.f1;

import java.util.ArrayList;

public class Engineer extends Person{

    ArrayList<Pilot> pilotsOfTeam;

    public Engineer(String name, int age, String nationality, ArrayList<Pilot> pilotsOfTeam){
        super(name, age, nationality);
        this.pilotsOfTeam=pilotsOfTeam;
    }

    public ArrayList<Pilot> getPilotsOfTeam() {
        return pilotsOfTeam;
    }

    public void setPilotsOfTeam(ArrayList<Pilot> pilotsOfTeam) { this.pilotsOfTeam = pilotsOfTeam; }
}
